execute as @s rotated as @s run summon armor_stand ^ ^2 ^1 {Invisible:1b,NoGravity:1b,Silent:1b,Invulnerable:1b,ShowArms:0b,Small:1b,NoBasePlate:1b,Tags:["needs_rotation","ray"]}
execute as @e[tag=needs_rotation] at @s run function herobrine:ray_cast/get_rotated
execute as @e[tag=ray] at @s run tp @s ^ ^ ^1.5
execute as @e[tag=herobrine] at @s if entity @e[tag=ray,distance=..8] run function herobrine:mechanics/looking_at_herobrine
execute as @e[tag=ray] at @s unless block ^ ^ ^1 air run kill @s
