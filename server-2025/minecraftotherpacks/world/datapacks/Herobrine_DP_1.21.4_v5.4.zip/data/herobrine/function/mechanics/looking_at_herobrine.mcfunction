# this function is called whenever a player looks into herobrines general direction
# it has a short delay called disappear_delay, so you can actually see him before he vanishes
# this would be the perfect function for adding a custom "vanishing sound" for herobrine
scoreboard players add @s disappear_delay 1
execute if score @s disappear_delay matches 2 run execute at @s run particle smoke ~ ~1 ~ 1 0.5 1 0.05 100 force
execute if score @s disappear_delay matches 2 at @s run playsound ambient.cave player @p ~ ~ ~ 1.0 1.0 1.0
execute if score @s disappear_delay matches 2 run tp @s ~ ~-70 ~
execute if score @s disappear_delay matches 2 run execute in overworld run tp @s 0 -70 0
execute if score @s disappear_delay matches 2 run scoreboard players set @s is_hidden 1
execute if score @s disappear_delay matches 2 run scoreboard players set @s reset_herobrine_timer 0
execute if score @s disappear_delay matches 2 run scoreboard players set @s disappear_delay 0