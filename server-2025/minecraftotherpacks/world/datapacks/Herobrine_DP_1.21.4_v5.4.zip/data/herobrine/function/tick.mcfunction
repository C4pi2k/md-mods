# this data pack was created by Sir_Doom_Turtle! https://www.youtube.com/channel/UCpwMPVXoUKe-fSewnVL82Ng

execute as @e[tag=herobrine_timer] run scoreboard players add @s herobrine_ticks 1
execute as @e[tag=herobrine_timer,scores={herobrine_ticks=5}] run function herobrine:1_second
execute as @e[tag=herobrine_timer,scores={herobrine_ticks=20..}] run scoreboard players set @s herobrine_ticks 0

# this check has to be execute every tick so herobrine does not end up in unloaded chunks, for example if a player switches dimensions
execute at @e[tag=herobrine,scores={is_hidden=0}] unless entity @p[distance=..96] run function herobrine:mechanics/reset_herobrine

# looking at herobrine detection every tick, but only when he is active, and only to players within 96 blocks of him
execute if score @e[tag=herobrine,limit=1] is_hidden matches 0 at @e[tag=herobrine] run execute as @a[distance=..96] at @s run function herobrine:ray_cast/cast

# kill rays that go too far
execute as @e[tag=ray] run scoreboard players add @s ray_timer 1
kill @e[tag=ray,scores={ray_timer=30..}]

execute as @e[tag=herobrine,scores={is_hidden=0}] at @s run tp @s ~ ~ ~ facing entity @p eyes