# this function runs whenever herobrine is active around a player
# right now, all it does is make it so that herobrine always faces the nearest player
# you can add onto this function if you want to make herobrine do other things when he is around the player
# the last command in this file resets herobrine if nobody has found him for 2.5 minutes (3000 ticks)

scoreboard players add @s reset_herobrine_timer 1
execute as @e[tag=herobrine] if score @s reset_herobrine_timer matches 180 run execute as @e[tag=herobrine] run function herobrine:mechanics/reset_herobrine


execute at @e[tag=herobrine] if block ~ ~-1 ~ #flowers run tp @e[tag=herobrine] ~ ~-1 ~
execute at @e[tag=herobrine] if block ~ ~-1 ~ short_grass run tp @e[tag=herobrine] ~ ~-1 ~
execute at @e[tag=herobrine] if block ~ ~-1 ~ tall_grass run tp @e[tag=herobrine] ~ ~-2 ~