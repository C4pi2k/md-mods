
execute as @e[tag=needs_rotation] at @s rotated as @p run tp @s ~ ~ ~ ~ ~
tag @s remove needs_rotation