

# this function checks if a crying obsidian is being sacrificed on a herobrine shrine
execute as @e[type=item,nbt={Item:{id:"minecraft:crying_obsidian"}}] run function herobrine:shrine/check_shrine

# this function checks if a diamond is being sacrificed on a herobrine shrine
execute as @e[type=item,nbt={Item:{id:"minecraft:diamond"}}] run function herobrine:shrine/check_shrine_deactivate

execute as @e[tag=herobrine] run scoreboard players add @s herobrine_seconds 1

execute as @e[tag=herobrine,scores={herobrine_seconds=59,is_hidden=1}] run scoreboard players add @s herobrine_cooldown 1

execute as @e[tag=herobrine,scores={herobrine_seconds=60..}] run scoreboard players set @s herobrine_seconds 0

# this command runs a function whenever herobrine is around a player
execute as @e[tag=herobrine] if score @s is_hidden matches 0 run function herobrine:mechanics/herobrine_active

# this command spawns herobrine around a random player whenever his cooldown expires. (default value 24000 ticks, 20 real life minutes)
execute as @e[tag=herobrine] if score @s herobrine_cooldown matches 20 run function herobrine:mechanics/spawn_herobrine

