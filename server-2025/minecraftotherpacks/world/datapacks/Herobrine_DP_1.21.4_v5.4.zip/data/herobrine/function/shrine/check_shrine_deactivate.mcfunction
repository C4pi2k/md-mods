# this function just checks every diamond item on the floor to see if it is sitting on a valid herobrine shrine

execute at @s if block ~ ~-1 ~ netherrack run scoreboard players add @s shrine_deactivate_status 1

execute at @s if block ~ ~-2 ~ gold_block run scoreboard players add @s shrine_deactivate_status 1
execute at @s if block ~-1 ~-2 ~-1 gold_block run scoreboard players add @s shrine_deactivate_status 1
execute at @s if block ~1 ~-2 ~1 gold_block run scoreboard players add @s shrine_deactivate_status 1
execute at @s if block ~-1 ~-2 ~1 gold_block run scoreboard players add @s shrine_deactivate_status 1
execute at @s if block ~1 ~-2 ~-1 gold_block run scoreboard players add @s shrine_deactivate_status 1
execute at @s if block ~1 ~-2 ~ gold_block run scoreboard players add @s shrine_deactivate_status 1
execute at @s if block ~-1 ~-2 ~ gold_block run scoreboard players add @s shrine_deactivate_status 1
execute at @s if block ~ ~-2 ~1 gold_block run scoreboard players add @s shrine_deactivate_status 1
execute at @s if block ~ ~-2 ~-1 gold_block run scoreboard players add @s shrine_deactivate_status 1

execute at @s if block ~1 ~-1 ~ redstone_torch run scoreboard players add @s shrine_deactivate_status 1
execute at @s if block ~-1 ~-1 ~ redstone_torch run scoreboard players add @s shrine_deactivate_status 1
execute at @s if block ~ ~-1 ~1 redstone_torch run scoreboard players add @s shrine_deactivate_status 1
execute at @s if block ~ ~-1 ~-1 redstone_torch run scoreboard players add @s shrine_deactivate_status 1

# if the diamond is on a valid shrine, the shrine is deactiveted using the shrine_deactivate function
execute at @s if score @s shrine_deactivate_status matches 14 run schedule function herobrine:shrine/shrine_deactivate 20t

