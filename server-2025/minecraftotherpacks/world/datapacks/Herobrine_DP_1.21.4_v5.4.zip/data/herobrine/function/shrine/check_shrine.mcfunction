# this function checks every crying obsidian item to see if it is on a valid herobrine shrine

execute at @s if block ~ ~-1 ~ netherrack run scoreboard players add @s shrine_check_status 1
execute at @s if block ~ ~-2 ~ gold_block run scoreboard players add @s shrine_check_status 1
execute at @s if block ~-1 ~-2 ~-1 gold_block run scoreboard players add @s shrine_check_status 1
execute at @s if block ~1 ~-2 ~1 gold_block run scoreboard players add @s shrine_check_status 1
execute at @s if block ~-1 ~-2 ~1 gold_block run scoreboard players add @s shrine_check_status 1
execute at @s if block ~1 ~-2 ~-1 gold_block run scoreboard players add @s shrine_check_status 1
execute at @s if block ~1 ~-2 ~ gold_block run scoreboard players add @s shrine_check_status 1
execute at @s if block ~-1 ~-2 ~ gold_block run scoreboard players add @s shrine_check_status 1
execute at @s if block ~ ~-2 ~1 gold_block run scoreboard players add @s shrine_check_status 1
execute at @s if block ~ ~-2 ~-1 gold_block run scoreboard players add @s shrine_check_status 1

execute at @s if block ~1 ~-1 ~ redstone_torch run scoreboard players add @s shrine_check_status 1
execute at @s if block ~-1 ~-1 ~ redstone_torch run scoreboard players add @s shrine_check_status 1
execute at @s if block ~ ~-1 ~1 redstone_torch run scoreboard players add @s shrine_check_status 1
execute at @s if block ~ ~-1 ~-1 redstone_torch run scoreboard players add @s shrine_check_status 1

# if the shrine is valid, any old herobrines are killed and a new one is spawned (to stop duplicates from occuring)
execute at @s if score @s shrine_check_status matches 14 run function herobrine:mechanics/init_herobrine
execute at @s if score @s shrine_check_status matches 14 run schedule function herobrine:shrine/shrine_activate 20t


