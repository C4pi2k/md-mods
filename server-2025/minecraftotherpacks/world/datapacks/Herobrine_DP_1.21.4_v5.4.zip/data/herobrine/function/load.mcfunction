# this data pack was created by Sir_Doom_Turtle! https://www.youtube.com/channel/UCpwMPVXoUKe-fSewnVL82Ng


# this is the load function, it is called exactly once when you reload your world

# this command causes herobrines chunk to always be loaded so the data pack works as intended
# this command was added because the spawn chunks would sometimes be too far from 0 0 to load herobrine
forceload add 0 0
kill @e[tag=herobrine_timer]
summon marker 0 -65 0 {NoGravity:1b,Silent:1b,Invulnerable:1b,Tags:["herobrine_timer"]}

# scoreboard values for all shrine related things
scoreboard objectives add shrine_check_status dummy
scoreboard objectives add shrine_deactivate_status dummy
scoreboard players set @e shrine_check_status 0
scoreboard players set @e shrine_deactivate_status 0

# scoreboard timer for the herobrine timings
scoreboard objectives add herobrine_ticks dummy
scoreboard objectives add herobrine_seconds dummy

# scoreboard timer for ray casts
scoreboard objectives add ray_timer dummy

# scoreboard for herobrine variables
scoreboard objectives add is_hidden dummy
scoreboard objectives add disappear_delay dummy
scoreboard objectives add herobrine_cooldown dummy
scoreboard objectives add reset_herobrine_timer dummy





