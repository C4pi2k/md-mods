# this function simply "vanishes" herobrine and resets all his scores
# when herobrine is reset, there won't be any sounds or particles, because it is assumed that herobrine spawned in a nearby cave where he could not be seen, so the sound and particle effects are unnecessary
execute as @e[tag=herobrine] run tp @s ~ ~-70 ~
execute as @e[tag=herobrine] run execute in overworld run tp @s 0 -70 0
execute as @e[tag=herobrine] run scoreboard players set @s is_hidden 1
execute as @e[tag=herobrine] run scoreboard players set @s reset_herobrine_timer 0
execute as @e[tag=herobrine] run scoreboard players set @s disappear_delay 0