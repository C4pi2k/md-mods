kill @e[tag=herobrine]

summon armor_stand 0 -70 0 {CustomNameVisible:0b,NoGravity:1b,Silent:1b,Invulnerable:1b,Invisible:1b,NoBasePlate:1b,Tags:["herobrine"],ArmorItems:[{},{},{},{id:"minecraft:carved_pumpkin",count:1,components:{"minecraft:item_model":"minecraft:herobrine"}}],CustomName:'"Herobrine"'}

# initialize the scoreboard values
execute as @e[tag=herobrine] run scoreboard players set @s is_hidden 1
execute as @e[tag=herobrine] run scoreboard players set @s disappear_delay 0
execute as @e[tag=herobrine] run scoreboard players set @s herobrine_cooldown 0
execute as @e[tag=herobrine] run scoreboard players set @s reset_herobrine_timer 0