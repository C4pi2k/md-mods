# this function simply summons a lightning bolt at the shrine and plays some sounds
# it does not actually spawn herobrine
tellraw @a {"text":"You don't know what you have done...","bold":true,"color":"dark_red"}
execute at @e[type=item,nbt={Item:{id:"minecraft:crying_obsidian"}}] run summon lightning_bolt ~ ~ ~
playsound block.end_portal.spawn master @a ~ ~ ~ 1 0.5 1