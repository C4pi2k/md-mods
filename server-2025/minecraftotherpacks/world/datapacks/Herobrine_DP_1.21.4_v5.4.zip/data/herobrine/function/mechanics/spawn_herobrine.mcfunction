# this funciton is responsible for spawning herobrine around a random player
# I recommend looking up the /spreadplayers command if you want to change the spawning radius of herobrine
# this funciton would be perfect for adding a custom "appear sound" for herobrine
scoreboard players set @s is_hidden 0
scoreboard players set @s herobrine_cooldown 0
execute at @r[nbt={Dimension:"minecraft:overworld"}] run spreadplayers ~ ~ 12 22 false @e[type=armor_stand,tag=herobrine]

execute at @e[type=armor_stand,tag=herobrine] run function herobrine:mechanics/render_bug_fix