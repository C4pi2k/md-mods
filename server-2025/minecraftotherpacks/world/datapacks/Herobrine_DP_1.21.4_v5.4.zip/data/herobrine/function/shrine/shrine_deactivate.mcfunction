# this function is called if the shrine is deactivated
# it simply kills herobrine, summons a lightning bolt, plays a soud, and puts a message in chat
kill @e[tag=herobrine]
execute at @e[type=item,nbt={Item:{id:"minecraft:diamond"}}] run summon lightning_bolt ~ ~ ~
playsound block.end_portal.spawn master @a ~ ~ ~ 1 1 1
tellraw @a {"text":"A wave of relief washes over you","bold":true,"color":"aqua"}